﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonelKayit.Operasyon
{
    public class DataAccessLayer:Base.Yardim
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader reader;

        public DataAccessLayer()
        {
            con = new SqlConnection("data source=.; initial catalog = PersonelKayitİslemleri; user id=sa; password = 1;");
        }

        public void BaglantiAyarla()
        {
            if (con.State == System.Data.ConnectionState.Open)
                con.Close();
            else
                con.Open();
        }

        public int KayitEKLE(Entities.Kisi kisi)
        {
            int returnValue = 0;
            TryCatchKullan(() => 
            {
                cmd = new SqlCommand("KisiEkle", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add("@Isim", SqlDbType.NVarChar).Value = kisi.Isim;
                cmd.Parameters.Add("@Soyisim", SqlDbType.NVarChar).Value = kisi.Soyisim;
                cmd.Parameters.Add("@EmailAdres", SqlDbType.NVarChar).Value = kisi.EmailAdres;
                cmd.Parameters.Add("@TelefonNumarasi", SqlDbType.NVarChar).Value = kisi.Tel;
                cmd.Parameters.Add("@Resim", SqlDbType.VarBinary).Value = kisi.Resim;
                BaglantiAyarla();
                returnValue = cmd.ExecuteNonQuery();
                BaglantiAyarla();
            });
            return returnValue;
        }

        public SqlDataReader KisiDetayGetir(int id)
        {
            TryCatchKullan(()=> 
            {
                cmd = new SqlCommand("select * from Kisiler where Id = @id", con);
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                BaglantiAyarla();
                reader = cmd.ExecuteReader();
               
            });
            return reader;
        }

        public SqlDataReader KisilerListe()
        {
            TryCatchKullan(() =>
            {
                cmd = new SqlCommand("select * from Kisiler", con);
                BaglantiAyarla();
                reader = cmd.ExecuteReader();

            });
            return reader;
        }
    }
}
