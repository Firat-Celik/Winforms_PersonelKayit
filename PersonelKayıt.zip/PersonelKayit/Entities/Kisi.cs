﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonelKayit.Entities
{
    public class Kisi
    {
        public int ID { get; set; }
        public string Isim { get; set; }
        public string Soyisim { get; set; }
        public string EmailAdres { get; set; }
        public string Tel { get; set; }
        public byte[] Resim { get; set; }

        public override string ToString()
        {
            return Isim + " " + Soyisim;
        }
    }
}
